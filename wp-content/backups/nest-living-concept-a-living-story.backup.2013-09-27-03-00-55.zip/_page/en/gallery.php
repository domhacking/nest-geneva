<div id="texte">
<div id="texte_title">The NEST concept is extending with the recent opening of NEST Gallery.</div><br />
<p>
It is now  possible to rent the ground floor of the NEST building. This space will serve as an outstanding gallery space of over 100m2. It comes equipped with all the material needed to host exhibitions or installations: a lighting system specifically optimized for artwork display, a backroom kitchen for cocktail receptions,  artwork hanging systems.<br />
<br />
You are free to make this space your own and decorate it according to your wishes.<br />
<br />
Please contact us directly through the contact form for further enquiries.<br />
<br />
&gt; <a href="../../_img/downloads/floorplans/NEST_Gallery_floorplan.pdf">Download Gallery floorplan here</a></p>
</div>
        <div id="right_image">
          
		  <?php 
				if(file_exists('_img/gallery.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/gallery.swf"/>';
					echo '<embed wmode="transparent" src="_img/gallery.swf" width="534" height="338"> </embed>  </object>';
				}
         ?>
        </div>