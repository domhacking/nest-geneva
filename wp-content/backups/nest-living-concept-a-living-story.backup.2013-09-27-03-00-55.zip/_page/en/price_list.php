<div id="texte">
<div id="texte_title">Download our brochure containing the full price lists and detailed information about the apartments.</div>
<br />
<br />
<br />
<br />

  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="2%"><img src="../../_img/pdf-icon-transparent.png" width="30" height="22" alt="pdf icon logo" /></td>
    <td width="98%"><a href="../../_img/downloads/NEST_Presentation&amp;Prices_2011-m.pdf" target="_blank">Download brochure price list</a></td>
  </tr>
</table>

</div>
        <div id="right_image">
          
		  <?php
				if(file_exists('_img/availability.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/availability.swf"/>';
					echo '<embed wmode="transparent" src="_img/availability.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/availability.jpg')){
					echo '<img src="_img/availability.jpg" />';
				}
         ?>
        </div>
