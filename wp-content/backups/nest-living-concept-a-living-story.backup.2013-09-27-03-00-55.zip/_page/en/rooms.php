<div id="texte">
<div id="texte_title">Three main types of living spaces available: Studio, Standard and Spacious.</div><br />
      <p>All our apartments come with fully equipped kitchens, as well as TV, wifi, and Bose sound systems. They are also all cleaned twice a week. All included in the monthly rate.<br />
      <br />For detailed information about each apartment and pricings, <strong><a href="../../_img/downloads/NEST_Presentation&amp;Prices_2011-m.pdf">view &lsquo;NEST Brochure&rsquo;.</a></strong>
        <br /><br />
        &gt; <a href="index.php?page=rooms&anim=room1" ><strong>View slideshow - STUDIO</strong></a><br />
        Up to 40m2 studios <br /><br />
        &gt; <a href="index.php?page=rooms&anim=room3" ><strong>View slideshow - STANDARD</strong></a><br />
        Up to 70m2; 3 rooms <br /><br />
        &gt; <a href="index.php?page=rooms&anim=room2" ><strong>View slideshow - SPACIOUS</strong></a><br />
        Up to and over 100m2; 5 rooms</p>
      
    </div>
    <div id="right_image">
      <?php 
	  			if(!empty($_GET['anim'])) $anim = $_GET['anim'];
				else $anim = 'room1';
				if(file_exists('_img/room1.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/'.$anim.'.swf"/>';
					echo '<embed wmode="transparent" src="_img/'.$anim.'.swf" width="534" height="338"> </embed>  </object>';
				}
         ?>
    </div>
