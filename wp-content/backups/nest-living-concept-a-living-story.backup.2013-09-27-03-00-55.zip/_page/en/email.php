<div id="texte"><?php 
	if(!empty($_POST['name']) && !empty($_POST['country']) && !empty($_POST['email'])){
		$votremail=$_POST["email"];
		$from=htmlspecialchars("From: ".$votremail);
		$destinataire="info@nest-geneva.ch";
		$objet="Booking Enquiry";
		
		
		$message = "Checking Availability : \n\n\n";
		$message .= "Forename & Surname : ".$_POST['name']."\n";
		$message .= "Country : ".$_POST['country']."\n";
		$message .= "Email : ".$_POST['email']."\n";
		if(!empty($_POST['phone']))
		$message .= "Phone number : ".$_POST['phone']."\n\n";
		$message .= "Dates from : ".$_POST['month_from']." ".$_POST['day_from']." ".$_POST['year_from']."\n";
		$message .= "To : ".$_POST['month_to']." ".$_POST['day_to']." ".$_POST['year_to']."\n";
		$message .= "\n\nInterested in :\n";
		if($_POST['studio'] == "on")
		$message .= "Studio \n";
		if($_POST['standard'] == "on")
		$message .= "Standard \n";
		if($_POST['spacious'] == "on")
		$message .= "Spacious ";
		if($_POST['gallery'] == "on")
		$message .= "Gallery ";

		
		
		if(!empty($_POST['comments']))
		$message .= "\n\n\nAdditional comments : ".$_POST['comments']."\n";
		
		
		if(mail($destinataire,$objet,$message,$from)){
				echo $output = 'Thank you for your interest. We will get back to you in the shortest delays.<br />
<br />
&gt; <a href="index.php" cstyle="color: blue;" >Return to homepage</a>';
		}
		else{
			echo $output = 'There was an error, please try again. <a href="index.php?page=availability" cstyle="color: blue;" >Go back</a>';	
		}
	}
	else{	
		echo '<p>You must fill in all the required fields... <a href="index.php?page=availability" cstyle="color: blue;" >Go back</a></p>';
	}
	?>
      </p>
    </div>
    <div id="right_image">
      <?php 
				if(file_exists('_img/room1.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/room1.swf"/>';
					echo '<embed wmode="transparent" src="_img/room1.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/room1.jpg')){
					echo '<img src="_img/room1.jpg" />';
				}
         ?>
    </div>
