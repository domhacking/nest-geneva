<div id="texte">
<div id="texte_title">NEST is an ongoing and evolving project.</div><br />
<p>NEST is located at number 12 and 14 Etienne-Dumont street, in Geneva's old city.<br />
<br />
Since a few years, NEST has become a living concept project aiming not only to provide accomodation to its guests, but a whole lifestyle experience. Some exciting development projects are underway, with plans of transforming the ground floor, backyard, and rooftop in "wellness extensions" such as a SPA center, an organic boutique restaurant, or a relaxing lounge & juice bar...<br />
<br />
Stay tuned!</p>
</div>
        <div id="right_image">
          
		  <?php 
				if(file_exists('_img/evolution.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/evolution.swf"/>';
					echo '<embed wmode="transparent" src="_img/evolution.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/evolution.jpg')){
					echo '<img src="_img/evolution.jpg" />';
				}
         ?>
        </div>