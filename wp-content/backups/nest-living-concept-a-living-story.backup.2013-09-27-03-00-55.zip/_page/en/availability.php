<div id="texte">
<div id="texte_title">To check for availability and place a booking, simply fill in the following form.</div><br />


&gt; <a href="_page/en/formavailability.php" title="Request availability" params="lightwindow_width=380,lightwindow_height=520" class="lightwindow page-options""> Booking form</a><br />


</div>
        <div id="right_image">
          
		  <?php
				if(file_exists('_img/availability.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/availability.swf"/>';
					echo '<embed wmode="transparent" src="_img/availability.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/availability.jpg')){
					echo '<img src="_img/availability.jpg" />';
				}
         ?>
        </div>
