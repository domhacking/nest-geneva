<div id="texte_geneva">
      <div id="links_geneva">
      <div id="texte_title">We care about providing you the most complete Geneva experience.</div><br />
        <p>Therefore, we have selected what we think are some of the most interesting addresses in the city. Please browse from the following categories:<br />
        </p>
        <p><br />
          <br />
          <?php 
			if(!empty($_GET['subpage'])){
				$subpage = $_GET['subpage'];
			}
			else {
				$subpage = "tourism";
			}
			?>
          <strong> > </strong><a <?php if($subpage=="tourism") echo 'class="yellow"'; ?> href="index.php?lang=en&page=geneva&subpage=tourism">Tourism</a><br />
          <strong> > </strong><a <?php if($subpage=="culture") echo 'class="yellow"'; ?> href="index.php?lang=en&page=geneva&subpage=culture">Culture</a><br />
          <strong> > </strong><a <?php if($subpage=="health") echo 'class="yellow"'; ?> href="index.php?lang=en&page=geneva&subpage=health">Health & SPA</a><br />
          <strong> > </strong><a <?php if($subpage=="restaurants") echo 'class="yellow"'; ?> href="index.php?lang=en&page=geneva&subpage=restaurants">Restaurants</a><br />
          <strong> > </strong><a <?php if($subpage=="nightlife") echo 'class="yellow"'; ?> href="index.php?lang=en&page=geneva&subpage=nightlife">NightLife</a><br />
          <strong> > </strong><a <?php if($subpage=="other") echo 'class="yellow"'; ?> href="index.php?lang=en&page=geneva&subpage=other">Other</a><br />
        </p>
      </div>
      <div id="sublinks_geneva">
        <?php 
			include('_page/en/subpage/'.$subpage.'.html');
 		?>
      </div>
    </div>
    <div id="right_image_geneva">
      <?php
				if(file_exists('_img/geneva-links.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/geneva-links.swf"/>';
					echo '<embed wmode="transparent" src="_img/geneva-links.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/geneva-links.jpg')){
					echo '<img src="_img/geneva-links.jpg" />';
				}
         ?>
    </div>
