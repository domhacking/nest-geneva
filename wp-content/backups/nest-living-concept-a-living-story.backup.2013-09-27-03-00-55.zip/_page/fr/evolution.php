<div id="texte">
<div id="texte_title">NEST est un projet en �volution perp�tuelle.</div><br />
<p>NEST est situ� au num�ros 12 et 14 de la rue Etienne-Dumont, au coeur de la vielle ville de Gen�ve.<br />
<br />
Depuis maintenant quelques ann�es, NEST s'est d�velopp� en espaces habitables ayant pour objectif d'offrir une exp�rience de vie compl�te davantage qu'un simple logement. Des projets d'int�gration "d'extensions wellness" tels qu'un SPA, un restaurant-boutique aux produits naturels, un espace lounge-d�tente, ou encore un "juice bar" sont en cours d'�valuation.<br />
<br />
Repassez nous voir prochainement...</p>
</div>
        <div id="right_image">
          
		  <?php 
				if(file_exists('_img/evolution.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/evolution.swf"/>';
					echo '<embed wmode="transparent" src="_img/evolution.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/evolution.jpg')){
					echo '<img src="_img/evolution.jpg" />';
				}
         ?>
        </div>