<div id="texte">
<div id="texte_title">T&eacute;l&eacute;charger notre brochure contenant la liste des prix.</div><br />
<br />
<br />
<br />
<br />
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="2%"><img src="../../_img/pdf-icon-transparent.png" width="30" height="22" alt="pdf icon logo" /></td>
    <td width="98%"><a href="../../_img/NEST_Presentation&amp;Prices_0710.pdf" target="_blank">T&eacute;l&eacute;charger brochure liste de prix</a></td>
  </tr>
</table>

</div>
        <div id="right_image">
          
		  <?php
				if(file_exists('_img/availability.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/availability.swf"/>';
					echo '<embed wmode="transparent" src="_img/availability.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/availability.jpg')){
					echo '<img src="_img/availability.jpg" />';
				}
         ?>
        </div>
