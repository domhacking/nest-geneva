<div id="texte">
<div id="texte_title">Pour v�rifier la disponibilit� et effectuer une r�servation, veuillez remplir le formulaire suivant.</div><br />


&gt; <a href="_page/fr/formavailability.php" title="Request availability" params="lightwindow_width=380,lightwindow_height=520" class="lightwindow page-options""> Formulaire de r�servation</a><br />


</div>
        <div id="right_image">
          
		  <?php
				if(file_exists('_img/availability.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/availability.swf"/>';
					echo '<embed wmode="transparent" src="_img/availability.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/availability.jpg')){
					echo '<img src="_img/availability.jpg" />';
				}
         ?>
        </div>
