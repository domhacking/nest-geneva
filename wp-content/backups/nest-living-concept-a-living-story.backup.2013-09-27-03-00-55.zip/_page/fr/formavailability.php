
<style type="text/css">
table{
	color:#000000;
}
.left{
	text-align:left;
	height:20px;
	padding-top:5px;
}
a{
	text-decoration:none;
}
#lol{
	width:100%;
	text-align:center;
}
</style>
<div id="lol">
<form id="formul" name="formul" action="index.php?lang=fr&page=email" method="post">
<table width="350px">
<tr>
	<td class="left">Nom et pr&eacute;nom*</td>
	<td><input type="text" name="name" id="name" /></td>
</tr>
<tr>
	<td class="left">Pays de r&eacute;sidence*</td>
	<td><input type="text" name="country" id="country" /></td>
</tr>
<tr>
	<td class="left">Email*</td>
	<td><input type="text" name="email" id="email" /></td>
</tr>
<tr>
	<td class="left">T&eacute;l&eacute;phone</td>
	<td><input type="text" name="phone" id="phone" /></td>
</tr>
<td colspan="2" class="left">&nbsp;</td>
<tr>
	<td colspan="2" class="left"><br />
	<b>Interess&eacute; par :<b><br /></td>
</tr>
<tr>
	  <td colspan="2" class="left">
	<b><br />
	Nest Living - Chambres :<b><br /></td>
</tr>
	<td class="left">Studio<br /></td>
	<td class="left"><input type="checkbox" name="studio" id="studio" /></td>
</tr>
	<td class="left">Standard<br /></td>
	<td class="left"><input type="checkbox" name="standard" id="standard" /></td>
</tr>
	<td class="left">Spacious<br /></td>
	<td class="left"><input type="checkbox" name="spacious" id="spacious" /></td>
</tr>
<tr>
	  <td colspan="2" class="left"><br />
	<b><br />
	Nest Galerie - Espace &agrave; louer :<b><br /></td>
</tr>
	    <td class="left">Espace galerie<br /></td>
	<td class="left"><input type="checkbox" name="gallery" id="gallery" /></td>
</tr>
<tr>
	<td colspan="2" class="left">&nbsp;</td>
<tr />

<tr>
<td class="left">
Du : </td>

<td class="left">
<select name="day_from" >
	<option value="day">Jour</option>
    <option value='01'>01</option>
    <option value='02'>02</option>
    <option value='03'>03</option>
    <option value='04'>04</option>
    <option value='05'>05</option>
    <option value='06'>06</option>
    <option value='07'>07</option>
    <option value='08'>08</option>
    <option value='09'>09</option>
    <option value='10'>10</option>
    <option value='11'>11</option>
    <option value='12'>12</option>
    <option value='13'>13</option>
    <option value='14'>14</option>
    <option value='15'>15</option>
    <option value='16'>16</option>
    <option value='17'>17</option>
    <option value='18'>18</option>
    <option value='19'>19</option>
    <option value='20'>20</option>
    <option value='21'>21</option>
    <option value='22'>22</option>
    <option value='23'>23</option>
    <option value='24'>24</option>
    <option value='25'>25</option>
    <option value='26'>26</option>
    <option value='27'>27</option>
    <option value='28'>28</option>
    <option value='29'>29</option>
    <option value='30'>30</option>
    <option value='31'>31</option>
</select>
<select name="month_from">
	<option value="month">Mois</option>
    <option value='January'>Janvier</option>
    <option value='February'>F&eacute;vrier</option>
    <option value='March'>Mars</option>
    <option value='April'>Avril</option>
    <option value='May'>Mai</option>
    <option value='June'>Juin</option>
    <option value='July'>Juillet</option>
    <option value='August'>Ao&ucirc;t</option>
    <option value='September'>Septembre</option>
    <option value='October'>Octobre</option>
    <option value='November'>Novembe</option>
    <option value='December'>Decembe</option>
</select>
<select name="year_from">
	<option value="year">Ann&eacute;e</option>
    <option value="2010">2010</option>
    <option value="2011">2011</option>
    <option value="2012">2012</option>
    <option value="2012">2013</option>
</select>
</td>
</tr>
<tr>
<td class="left">au :</td>
<td class="left">
<select name="day_to">
	<option value="day">Jour</option>
    <option value='01'>01</option>
    <option value='02'>02</option>
    <option value='03'>03</option>
    <option value='04'>04</option>
    <option value='05'>05</option>
    <option value='06'>06</option>
    <option value='07'>07</option>
    <option value='08'>08</option>
    <option value='09'>09</option>
    <option value='10'>10</option>
    <option value='11'>11</option>
    <option value='12'>12</option>
    <option value='13'>13</option>
    <option value='14'>14</option>
    <option value='15'>15</option>
    <option value='16'>16</option>
    <option value='17'>17</option>
    <option value='18'>18</option>
    <option value='19'>19</option>
    <option value='20'>20</option>
    <option value='21'>21</option>
    <option value='22'>22</option>
    <option value='23'>23</option>
    <option value='24'>24</option>
    <option value='25'>25</option>
    <option value='26'>26</option>
    <option value='27'>27</option>
    <option value='28'>28</option>
    <option value='29'>29</option>
    <option value='30'>30</option>
    <option value='31'>31</option>
</select>
<select name="month_to">
	<option value="month">Mois</option>
    <option value='January'>Janvier</option>
    <option value='February'>F&eacute;vrier</option>
    <option value='March'>Mars</option>
    <option value='April'>Avril</option>
    <option value='May'>Mai</option>
    <option value='June'>Juin</option>
    <option value='July'>Juillet</option>
    <option value='August'>Ao&ucirc;t</option>
    <option value='September'>Septembre</option>
    <option value='October'>Octobre</option>
    <option value='November'>Novembe</option>
    <option value='December'>Decembe</option>
</select>
<select name="year_to">
	<option value="year">Ann&eacute;e</option>
	<option value="2008">2008</option>
	<option value="2009">2009</option>
    <option value="2010">2010</option>
    <option value="2011">2011</option>
    <option value="2012">2012</option>
</select>
</td>
</tr>

<tr>
	<td colspan="2" class="left">&nbsp;</td>
<tr />


<tr>
	<td colspan="2" class="left">Commentaires ou message</td>
<tr />
<tr>
	<td colspan="2" class="left"><textarea name="comments" id="comments" cols="35" rows="5"></textarea></td>
	
</tr>


<tr><td colspan="2"><input type="submit" value="Envoyer" name="submit" />
ou <a href="index.php?page=availability" cstyle="color: blue;" >fermer</a></center> 
</td>


</table>
</form>
</div>