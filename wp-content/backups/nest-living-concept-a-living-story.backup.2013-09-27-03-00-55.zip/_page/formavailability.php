
<style type="text/css">
table{
	color:#000000;
}
.left{
	text-align:left;
	height:20px;
	padding-top:5px;
}
a{
	text-decoration:none;
}
#lol{
	width:100%;
	text-align:center;
}
</style>
<div id="lol">
<form id="formul" name="formul" action="index.php?page=email" method="post">
<table width="350px">
<tr>
	<td class="left">Name &amp; surname*</td>
	<td><input type="text" name="name" id="name" /></td>
</tr>
<tr>
	<td class="left">Country of residence*</td>
	<td><input type="text" name="country" id="country" /></td>
</tr>
<tr>
	<td class="left">Email*</td>
	<td><input type="text" name="email" id="email" /></td>
</tr>
<tr>
	<td class="left">Phone number</td>
	<td><input type="text" name="phone" id="phone" /></td>
</tr>
<td colspan="2" class="left">&nbsp;</td>
<tr>
	<td colspan="2" class="left"><br /><b>Interested in :<b><br /></td>
</tr>
<tr>
	  <td colspan="2" class="left">
	<b><br />
	Nest Living - Rooms :<b><br /></td>
</tr>
	<td class="left">Studio<br /></td>
	<td class="left"><input type="checkbox" name="studio" id="studio" /></td>
</tr>
	<td class="left">Standard<br /></td>
	<td class="left"><input type="checkbox" name="standard" id="standard" /></td>
</tr>
	<td class="left">Spacious<br /></td>
	<td class="left"><input type="checkbox" name="spacious" id="spacious" /></td>
</tr>
<tr>
	  <td colspan="2" class="left"><br />
	<b><br />
	Nest Gallery - The Space:<b><br /></td>
</tr>
	  <td class="left">Gallery space<br /></td>
	<td class="left"><input type="checkbox" name="gallery" id="gallery" /></td>
</tr>

<tr>
<td class="left">
From : </td>

<td class="left"><select name="month_from">
    <option value='January'>January</option>
    <option value='February'>February</option>
    <option value='March'>March</option>
    <option value='April'>April</option>
    <option value='May'>May</option>
    <option value='June'>June</option>
    <option value='July'>July</option>
    <option value='August'>August</option>
    <option value='September'>September</option>
    <option value='October'>October</option>
    <option value='November'>November</option>
    <option value='December'>December</option>
</select>
<select name="day_from" >
    <option value='01'>01</option>
    <option value='02'>02</option>
    <option value='03'>03</option>
    <option value='04'>04</option>
    <option value='05'>05</option>
    <option value='06'>06</option>
    <option value='07'>07</option>
    <option value='08'>08</option>
    <option value='09'>09</option>
    <option value='10'>10</option>
    <option value='11'>11</option>
    <option value='12'>12</option>
    <option value='13'>13</option>
    <option value='14'>14</option>
    <option value='15'>15</option>
    <option value='16'>16</option>
    <option value='17'>17</option>
    <option value='18'>18</option>
    <option value='19'>19</option>
    <option value='20'>20</option>
    <option value='21'>21</option>
    <option value='22'>22</option>
    <option value='23'>23</option>
    <option value='24'>24</option>
    <option value='25'>25</option>
    <option value='26'>26</option>
    <option value='27'>27</option>
    <option value='28'>28</option>
    <option value='29'>29</option>
    <option value='30'>30</option>
    <option value='31'>31</option>
</select>
<select name="year_from">
    <option value="2010">2010</option>
    <option value="2011">2011</option>
    <option value="2012">2012</option>
    <option value="2008">2013</option>
	<option value="2009">2014</option>
</select>
</td>
</tr>
<tr>
<td class="left">To :</td>
<td class="left"><select name="month_to">
    <option value='January'>January</option>
    <option value='February'>February</option>
    <option value='March'>March</option>
    <option value='April'>April</option>
    <option value='May'>May</option>
    <option value='June'>June</option>
    <option value='July'>July</option>
    <option value='August'>August</option>
    <option value='September'>September</option>
    <option value='October'>October</option>
    <option value='November'>November</option>
    <option value='December'>December</option>
</select>
<select name="day_to" >
    <option value='01'>01</option>
    <option value='02'>02</option>
    <option value='03'>03</option>
    <option value='04'>04</option>
    <option value='05'>05</option>
    <option value='06'>06</option>
    <option value='07'>07</option>
    <option value='08'>08</option>
    <option value='09'>09</option>
    <option value='10'>10</option>
    <option value='11'>11</option>
    <option value='12'>12</option>
    <option value='13'>13</option>
    <option value='14'>14</option>
    <option value='15'>15</option>
    <option value='16'>16</option>
    <option value='17'>17</option>
    <option value='18'>18</option>
    <option value='19'>19</option>
    <option value='20'>20</option>
    <option value='21'>21</option>
    <option value='22'>22</option>
    <option value='23'>23</option>
    <option value='24'>24</option>
    <option value='25'>25</option>
    <option value='26'>26</option>
    <option value='27'>27</option>
    <option value='28'>28</option>
    <option value='29'>29</option>
    <option value='30'>30</option>
    <option value='31'>31</option>
</select>
<select name="year_to">
	<option value="2010">2010</option>
    <option value="2011">2011</option>
    <option value="2012">2012</option>
    <option value="2008">2013</option>
	<option value="2009">2014</option>
</select>
</td>
</tr>

<tr>
	<td colspan="2" class="left">&nbsp;</td>
<tr />


<tr>
	<td colspan="2" class="left">Additional comments or message</td>
<tr />
<tr>
	<td colspan="2" class="left"><textarea name="comments" id="comments" cols="35" rows="5"></textarea></td>
	
</tr>


<tr><td colspan="2"><input type="submit" value="Submit" name="submit" />
or <a href="index.php?page=availability" cstyle="color: blue;" >Close</a></center> 
</td>


</table>
</form>
</div>