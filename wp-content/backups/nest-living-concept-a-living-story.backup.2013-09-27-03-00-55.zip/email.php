
<style type="text/css">
#lol{
	width:300px;
	padding-top:20px;
	color:#000000;
	text-align:center;
		padding-bottom:10px;
}
a{
	text-decoration:none;
}
</style>

<div id="lol"><?php
	
</div>