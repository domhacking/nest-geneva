<div id="texte">
<div id="texte_title">NEST Living Concept offers short-term rent of high-end, fully furnished apartments right in the heart of Geneva � Switzerland.</div><br />
<p>Contemporary yet cosy, up-market yet homely, all our NEST apartments will give you that �home away from home� feeling.</p>
<p>
<br />
Beautifully located in the centre of the old town, now you can immerse yourself in the history of your surroundings while enjoying the modern comfort of individually designed  spaces.</p>
<p>
<br />Feel at home, feel away, feel good.</p>
</div>
<div id="right_image">
          
		  <?php if($page == "philosophy"){
					$anim= "philo";
				}
				if($page == "rooms"){
					$anim= "room1";
				}
				if($page== "availability"){
					$anim="availability";
				}
				if($page== "evolution"){
					$anim="evolution";
				}
				if($page== "geneva"){
					$anim="geneva-links";
				}
				if($page== "contact"){
					$anim="contact";
				}
				if(file_exists('_img/philo.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/philo.swf"/>';
					echo '<embed wmode="transparent" src="_img/philo.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/philo.jpg')){
					echo '<img src="_img/philo.jpg" />';
				}
         ?>
        </div>