<div id="texte_geneva">
      <div id="links_geneva">
      <div id="texte_title">L'exp�rience Gen�ve � plein potentiel.</div><br />
        <p>Notre objectif est de vous faire d�couvrir "l'exp�rience Gen�ve" de la fa�on la plus compl�te qui soit. Dans ce but, nous avons s�lectionn� ce que nous pensons repr�sente les addresses les plus int�ressantes de la ville et alentours :<br />
        </p>
        <p><br />
          <br />
          <?php 
			if(!empty($_GET['subpage'])){
				$subpage = $_GET['subpage'];
			}
			else {
				$subpage = "tourism";
			}
			?>
          <strong> > </strong><a <?php if($subpage=="tourism") echo 'class="yellow"'; ?> href="index.php?lang=fr&page=geneva&subpage=tourism">Tourisme</a><br />
          <strong> > </strong><a <?php if($subpage=="culture") echo 'class="yellow"'; ?> href="index.php?lang=fr&page=geneva&subpage=culture">Culture</a><br />
          <strong> > </strong><a <?php if($subpage=="health") echo 'class="yellow"'; ?> href="index.php?lang=fr&page=geneva&subpage=health">SPA & Sant�</a><br />
          <strong> > </strong><a <?php if($subpage=="restaurants") echo 'class="yellow"'; ?> href="index.php?lang=fr&page=geneva&subpage=restaurants">Restaurants</a><br />
          <strong> > </strong><a <?php if($subpage=="nightlife") echo 'class="yellow"'; ?> href="index.php?lang=fr&page=geneva&subpage=nightlife">Gen�ve la nuit</a><br />
          <strong> > </strong><a <?php if($subpage=="other") echo 'class="yellow"'; ?> href="index.php?lang=fr&page=geneva&subpage=other">Autres adresses</a><br />
        </p>
      </div>
      <div id="sublinks_geneva">
        <?php 
			include('_page/fr/subpage/'.$subpage.'.html');
 		?>
      </div>
    </div>
    <div id="right_image_geneva">
      <?php
				if(file_exists('_img/geneva-links.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/geneva-links.swf"/>';
					echo '<embed wmode="transparent" src="_img/geneva-links.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/geneva-links.jpg')){
					echo '<img src="_img/geneva-links.jpg" />';
				}
         ?>
    </div>
