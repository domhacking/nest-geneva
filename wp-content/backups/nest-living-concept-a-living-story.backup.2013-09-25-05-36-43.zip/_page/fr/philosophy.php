<div id="texte">
<div id="texte_title">NEST Living Concept propose des r�sidences meubl�es de haut standing � louer sur le court terme et situ&eacute;es en plein centre de Gen�ve - Suisse.</div><br />
<p>En alliant le contemporain au confortable, le prestige &agrave; l'intime, les appartements NEST mettent tout en oeuvre pour  vous procurer un sentiment de familiarit&eacute;. NEST est votre cocon loin de votre maison.<br />
  <br /> 
  Situ&eacute; au coeur de la vieille-ville, vous pourrez vous immerger dans un environnement historique incomparable, tout en profitant d'espaces habitables au confort moderne.<br />
  <br />
Soyez chez vous, soyez d�pays�, soyez bien!</p>
</div>
<div id="right_image">
          
		  <?php if($page == "philosophy"){
					$anim= "philo";
				}
				if($page == "rooms"){
					$anim= "room1";
				}
				if($page== "availability"){
					$anim="availability";
				}
				if($page== "evolution"){
					$anim="evolution";
				}
				if($page== "geneva"){
					$anim="geneva-links";
				}
				if($page== "contact"){
					$anim="contact";
				}
				if(file_exists('_img/philo.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/philo.swf"/>';
					echo '<embed wmode="transparent" src="_img/philo.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/philo.jpg')){
					echo '<img src="_img/philo.jpg" />';
				}
         ?>
        </div>