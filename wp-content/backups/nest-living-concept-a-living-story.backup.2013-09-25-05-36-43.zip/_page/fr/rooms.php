<div id="texte">
<div id="texte_title">Trois types d'appartements diff�rents sont disponibles: Studio, Standard et Spacious.</div><br />
      <p>Tous les appartements poss�dent salle de bain, cuisine �quip�e, TV, wifi et sound syst&egrave;me Bose. Le prix de location comprend le m&eacute;nage effectu&eacute; deux fois par semaine.<br />
        <br />
        Pour les prix et fiches techniques de chaque appartement, <strong><a href="../../_img/downloads/NEST_Presentation&amp;Prices_2011-m.pdf">t&eacute;l&eacute;charger la  Brochure NEST.</a></strong><br />
        <br />
        &gt; <a href="index.php?lang=fr&page=rooms&anim=room1" ><strong>Voir des visuels - STUDIO</strong></a><br />
        Superficie jusqu'� 40m2; 1 chambre.<br /><br />
        &gt; <a href="index.php?lang=fr&page=rooms&anim=room3" ><strong>Voir des visuels - STANDARD</strong></a><br />
        Superficie jusqu'� 70m2; 3 chambres.<br /><br />
        &gt; <a href="index.php?lang=fr&page=rooms&anim=room2" ><strong>Voir des visuels - SPACIOUS</strong></a><br />
Superficie jusqu'� 100m2; 5 chambres.<br />
    </p></div>
    <div id="right_image">
      <?php 
	  			if(!empty($_GET['anim'])) $anim = $_GET['anim'];
				else $anim = 'room1';
				if(file_exists('_img/room1.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/'.$anim.'.swf"/>';
					echo '<embed wmode="transparent" src="_img/'.$anim.'.swf" width="534" height="338"> </embed>  </object>';
				}
         ?>
    </div>
