<div id="texte">
<div id="texte_title">NEST Living Concept</div><br />
<p>Etienne-Dumont 12-14<br />
1204 Gen�ve<br /><br />
Phone: +41 (0)22 518 02 83<br />
Fax: +41 (0)22 310 45 73<br /><br />
Email: <a href="mailto:info@nest-geneva.ch">info@nest-geneva.ch</a></p>
<p><br />
&gt; <a href="http://maps.google.com/maps/ms?ie=UTF8&hl=en&msa=0&msid=108302552473605579512.000458e086f28565c6269&z=17" target="_blank">Situer sur une carte</a></p>
</div>
        <div id="right_image">
          
		  <?php
				if(file_exists('_img/contact.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/contact.swf"/>';
					echo '<embed wmode="transparent" src="_img/contact.swf" width="534" height="338"> </embed>  </object>';
				}
				if(file_exists('_img/contact.jpg')){
					echo '<img src="_img/contact.jpg" />';
				}
         ?>
        </div>