<div id="texte">
<div id="texte_title">NEST Concept s'agrandit avec l'ouverture de l'espace NEST Galerie.</div><br />
<p>
L'espace est situ&eacute; au bas de l'immeuble NEST. Il est possible de louer cet espace galerie de plus de 100m2 afin d'y tenir vos expositions. Tout le mat&eacute;riel n&eacute;cessaire est fourni: syst&egrave;me d'&eacute;clairage optimalis&eacute;, syst&egrave;me d'accrochage mural, ainsi qu'une mini cuisine en arri&egrave;re-salle pour organiser vos coktails de r&eacute;ception.<br />
<br />
Vous &ecirc;tes libre de transformer cet espace comme bon vous semble.<br />
<br />
Pour plus d'informations, merci de nous contacter directement via notre formulaire de r&eacute;servations en ligne.<br />
<br />
&gt; <a href="../../_img/downloads/floorplans/NEST_Gallery_floorplan.pdf">T&eacute;l&eacute;charger  le plan de la galerie ici</a></p>
</div>
        <div id="right_image">
          
		  <?php 
				if(file_exists('_img/gallery.swf')){
					echo '<object width="534" height="338" >';
					echo '<param name="movie" bame="wmode" value="transparent" value="_img/gallery.swf"/>';
					echo '<embed wmode="transparent" src="_img/gallery.swf" width="534" height="338"> </embed>  </object>';
				}
         ?>
        </div>